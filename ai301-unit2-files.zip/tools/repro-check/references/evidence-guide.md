# Evidence guide: where proof lives

## Environment

- Where it lives: In eval, compare the issue context and repo-facts block with the repro report's OS, version/commit, setup, and configuration. In live mode, read the issue and repository docs, then the draft's environment record.
- What good looks like: The record lets a stranger identify the tested code and platform. Record any driver, shell, build profile, or configuration on which this issue depends. If these differ from the issue, say so and explain the limit on the result. No particular heading or format is required.

## Steps

- Where it lives: In eval, compare the issue's trigger and supplied inputs with the repro report's commands and starting state. In live mode, compare the issue page and public setup docs with the draft's commands, input files, and interactions.
- What good looks like: A stranger can execute the steps using public code and supplied inputs, from preparation through the decisive command or action. Check exact operators, flags, argument order, versions, and special prerequisites; a superficially similar command can test another behavior.

## Behavior shown

- Where it lives: In eval, inspect output, logs, screenshots as described, test traces, exit status, or measurements in the repro report against the issue's expected and actual behavior. In live mode, inspect the artifacts pasted in the draft comment, not private files that only the author can see.
- What good looks like: The shown artifact has the symptom the issue alleges, or directly shows the absence of that symptom after a faithful attempt. A banner proves only the version; a screenshot of a running app proves only that it runs. Quote enough output for a reader to compare the precise error or value.

## Honesty

- Where it lives: Read the claim's promises and the report's conclusion alongside the issue trigger, recorded steps, and artifacts in either mode.
- What good looks like: “I reproduced” is supported by the actual failure; “I could not reproduce” gives a real attempt, result, and known differences. Hypotheses are labeled as hypotheses. A diagnosis, platform generalization, or claim of certainty does not outrun what was tested.

## Comms

- Where it lives: In eval, use the claim, report, and contribution policy in repo facts. In live mode, read the issue thread, `CONTRIBUTING.md`, any dedicated AI policy or comment template, and the student's draft comments; apply `voice-guide.md` too.
- What good looks like: The claim identifies this issue's behavior and promises investigation/reporting without promising a fix or date. The repro gives the evidence in the author's own words. When policy explicitly requires AI disclosure, state AI use in the comment; a permissive or silent policy does not create an invented disclosure rule. Shared classroom claims do not excuse copying another student's report.
