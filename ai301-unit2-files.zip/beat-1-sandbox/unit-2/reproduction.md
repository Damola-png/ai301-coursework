# Unit 2 — Claim and Reproduce

## Your identity upstream

**GitHub username**

Damola-png

## Posted upstream

**Claim comment**

Not posted yet; no permalink exists. Draft: `beat-1-sandbox/unit-2/drafts/claim.md`. After posting, paste the comment permalink and the exact posted text here.

**Reproduction comment**

Not posted yet; no permalink exists. Actual reproduction was run locally; draft: `beat-1-sandbox/unit-2/drafts/reproduction.md`. Post your own report after your claim, then paste its permalink and exact posted text here.

## Eval iterations

**Run history**

No harness run was completed in this workspace: the required Claude Code CLI is unavailable. Replace this with the actual agreement line(s) after running the course harness.

**Package analysis**

Pending the actual scored eval output. Record a scored `pkg-` id, your rubric's verdict, the gold verdict, and the evidence behind the result.

**Check rationale**

"The artifact actually shows the reported symptom under the stated trigger, or shows an observable non-reproduction under a faithful attempt. A version banner, nearby symptom, generic error, or mere assertion is insufficient. Interpret exit status and output literally; do not treat a normal validation error as a crash." This check focuses on the behavior in the output rather than the report's length or formatting; the eval set includes cases where a polished write-up describes a different error.

**Trade-offs**

The check can reject a genuine but poorly captured failure if the author did not include the decisive output. I accept that cost because the posted report must let a stranger distinguish this issue from a neighboring symptom.
