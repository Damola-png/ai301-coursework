**Reproduction report for #72**

**Environment:** Linux x86_64 (kernel 6.18.44), Python 3.12.14, PathReview `codepath/pathreview-ai301-fa26-s1` at commit `f89c06fc3ff292df2a04a39ac51319d32a76b779`. In a fresh virtual environment I installed `passlib[bcrypt]>=1.7.4`, `bcrypt>=4,<5`, `python-jose[cryptography]>=3.3.0`, `pydantic-settings>=2.1.0`, and `pytest`. Installed versions relevant to this test: passlib 1.7.4, bcrypt 4.3.0, pytest 9.1.1. This unit test runs without Docker or a `.env` file.

**Steps:** From the repository root with those packages installed, run:

```bash
python -m pytest tests/unit/test_security.py::TestSecurity::test_verify_with_wrong_hash_format -q --runxfail
```

The `--runxfail` flag makes pytest execute the existing test as a normal test without editing its `@pytest.mark.xfail` marker. That test calls `verify_password("password", "not_a_valid_bcrypt_hash")`.

**Expected:** `verify_password` returns `False` for an unrecognized stored hash, and the assertion passes.

**Observed:** The test fails before the `False` assertion. The relevant output is:

```text
>       result = verify_password("password", wrong_hash)
tests/unit/test_security.py:227:
core/security.py:37: in verify_password
    return bool(pwd_context.verify(plain_password, hashed_password))
...
E           passlib.exc.UnknownHashError: hash could not be identified
FAILED tests/unit/test_security.py::TestSecurity::test_verify_with_wrong_hash_format
1 failed, 2 warnings in 0.17s
```

Without `--runxfail`, the same targeted test reports `1 xfailed` because the marker expects this bug. As a control, I ran the existing `test_verify_password_correct` and `test_verify_password_incorrect` tests; both passed (`2 passed`). The two warnings concern Python's deprecated `crypt` module and Pydantic class-based config; neither is the `UnknownHashError` failure.

This confirms the reported malformed-hash behavior on the stated commit and environment. I have not changed the code or tested a fix.
